package com.example.fess.kotlinmassage1.service

import com.google.firebase.iid.FirebaseInstanceIdService

class MyFirebaseInstanceIDService: FirebaseInstanceIdService()  {



}